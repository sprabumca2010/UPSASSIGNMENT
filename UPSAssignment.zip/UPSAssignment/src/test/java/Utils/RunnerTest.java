package Utils;

import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@Cucumber.Options(
        format = {"pretty", "html:target/Destination"},
        features = "src/test/java/feature", glue={"StepDefinition"},
        dryRun = false,
        tags="@ups"
        )

public class RunnerTest {
}

;