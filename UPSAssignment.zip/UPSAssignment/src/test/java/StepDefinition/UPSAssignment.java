package StepDefinition;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import java.net.HttpURLConnection;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.openqa.selenium.Keys;

public class UPSAssignment {

    public static WebDriver driver = null;
    @Given("^user navigate to UPS home page$")
    public static void launch(){
        System.setProperty("webdriver.chrome.driver", "/UPSAssignment/Resource/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.ups.com/us/en/Home.page");
    }
    @And("^verify the ups logo$")
    public static void islogopresent(){
        WebElement logoPresent = driver.findElement(By.id("ups-header_logo"));
          if (logoPresent.isDisplayed()) {
              System.out.println("Logo is Exists");
          } else {
              System.out.println("Logo doesn't Exists");
          }

    }
    @Then("^Navigate to footer and count the footer links$")
        public static void totalfooterlink(){

        WebElement footerlinks = driver.findElement(By.className("ups-footer_colsCont"));
        List<WebElement> links = footerlinks.findElements(By.tagName("a"));
        int count = links.size();
        System.out.println("Total no of footer links:"+count);

    }
    @When("^User click the footer link and check the links are valid$")
    public static void validatefooterlink(){
        WebElement footerlinks = driver.findElement(By.className("ups-footer_colsCont"));
        List<WebElement> links = footerlinks.findElements(By.tagName("a"));
        HttpURLConnection huc = null;
        int respCode = 200;

        String LinkedInPage = "https://www.linkedin.com";
        Boolean bLinkedIn = false;
        int LinkedInStatus = 999;


        Iterator<WebElement> it = links.iterator();

        while(it.hasNext()){

            String url = it.next().getAttribute("href");


            try {
                huc = (HttpURLConnection)(new URL(url).openConnection());

                huc.setRequestMethod("HEAD");

                huc.connect();

                respCode = huc.getResponseCode();

                if(url.startsWith(LinkedInPage))
                {
                    bLinkedIn = true;
                }
                if(respCode >= 400) {
                    /* Linked Page 999 status code is valid */
                    if ((bLinkedIn == true) && (respCode == LinkedInStatus)) {
                        System.out.println(url + " is a LinkedIn Page and is not a broken link");

                    } else {
                        System.out.println("responsecode" + respCode);
                        System.out.println(url + " is a broken link");
                    }
                }
                else{
                    System.out.println(url+" is a valid link");
                }

            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }
    @Then("^The footer links are loading in new window$")
    public static void clickfooterlink() throws InterruptedException {
        WebElement footerlinks = driver.findElement(By.className("ups-footer_colsCont"));
        List<WebElement> links = footerlinks.findElements(By.tagName("a"));
               for (int i = 0; i < links.size(); i++) {
            String linksToOpen = Keys.chord(Keys.CONTROL, Keys.ENTER);
            links.get(i).sendKeys(linksToOpen);

        }

    }

}
